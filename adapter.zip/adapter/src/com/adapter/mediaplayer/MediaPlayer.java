package com.adapter.mediaplayer;

public interface MediaPlayer {

    public void play(String audioType, String fileName);
}
