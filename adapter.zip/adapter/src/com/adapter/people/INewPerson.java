package com.adapter.people;

public interface INewPerson {

    String getName();
    void setName(String name);
    int getAge();
    void  setAge(int age);

}
