package com.adapter.people;

public class NewPerson implements INewPerson {

    private String name;
    private int age;


    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name=name;

    }

    @Override
    public int getAge() {
        return 0;
    }

    @Override
    public void setAge(int age) {

    }


}
