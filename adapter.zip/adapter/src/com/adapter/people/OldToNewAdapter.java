package com.adapter.people;

import java.util.GregorianCalendar;

public class OldToNewAdapter implements INewPerson {
    private IOldPerson oldPerson;

    public OldToNewAdapter(IOldPerson oldPerson) {
        this.oldPerson = oldPerson;
    }

    @Override
    public String getName() {
        return oldPerson.getName() + " " + oldPerson.getLastName();
    }

    @Override
    public void setName(String allName) {

        String[] name = allName.split(" ");
        String firstName = name[0];
        String lastName = name[1];
        oldPerson.setName(firstName);
        oldPerson.setLastName(lastName);

    }

    @Override
    public int getAge() {
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(oldPerson.getBirthdate());
        return gregorianCalendar.get(1) - calendar.get(1);
    }

    @Override
    public void setAge(int age) {

        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        int yearActual = gregorianCalendar.get(1);
        gregorianCalendar.set(1, yearActual - age);
        oldPerson.setBirthdate(gregorianCalendar.getTime());

    }
}
