package com.adapter.people;

import java.util.Date;

public interface IOldPerson {

    String getName();
    void setName(String name);
    String getLastName();
    void setLastName(String lastName);
    Date getBirthdate();
    void setBirthdate(Date birthdate);
}
