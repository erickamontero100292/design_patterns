package com.adapter.people;

import java.util.Date;
import java.util.GregorianCalendar;

public class PeopleDemo {

    public static void main(String args[]){

        OldPerson oldPerson = new OldPerson();
        oldPerson.setLastName("Montero");
        oldPerson.setName("Ericka");
        GregorianCalendar date= new GregorianCalendar();
        date.set(1992,12,01);
        Date dateR = date.getTime();
        oldPerson.setBirthdate(dateR);

        OldToNewAdapter newPerson = new OldToNewAdapter(oldPerson);

        System.out.println(newPerson.getAge());
        System.out.println(newPerson.getName());

        newPerson.setAge(27);
        newPerson.setName("Ericka Montero");

        System.out.println(newPerson.getAge());
        System.out.println(newPerson.getName());
    }
}
