package com.builder;

public interface Packing {
    public String pack();
}
