package com.abstractfactory.shape;

import com.abstractfactory.shape.product.Shape;

public abstract class AbstractFactory {

    abstract Shape getShape(String shapeType);
}
