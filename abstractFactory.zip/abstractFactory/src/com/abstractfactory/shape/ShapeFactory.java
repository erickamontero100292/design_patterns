package com.abstractfactory.shape;

import com.abstractfactory.shape.product.Rectangle;
import com.abstractfactory.shape.product.Shape;
import com.abstractfactory.shape.product.Square;

public class ShapeFactory extends AbstractFactory {
    @Override
    public Shape getShape(String shapeType) {
        if (shapeType.equalsIgnoreCase("RECTANGLE")) {
            return new Rectangle();
        } else if (shapeType.equalsIgnoreCase("SQUARE")) {
            return new Square();
        }
        return null;
    }
}