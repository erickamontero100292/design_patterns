package com.abstractfactory.shape.product;

public interface Shape {

    void draw();
}
