package com.abstractfactory.furniture;

public class ClientFurniture {

    public static AbstractFactory getFactory(String styleFurniture){
        if(styleFurniture.equalsIgnoreCase("victorian")){
            return new VictorianFactory();
        }else{
            return new ModernFurnitureFactory();
        }
    }
}
