package com.abstractfactory.furniture.products.coffetable;

public class ModernItalianCoffeTable implements CoffeTable {

    @Override
    public void hasLegs() {
        System.out.println("hasLegs:ModernItalianCoffeTable ");
    }

    @Override
    public void sitOn() {

        System.out.println("sitOn:ModernItalianCoffeTable ");

    }
}

