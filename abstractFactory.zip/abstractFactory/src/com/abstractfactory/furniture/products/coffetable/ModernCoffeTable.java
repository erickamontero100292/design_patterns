package com.abstractfactory.furniture.products.coffetable;

public class ModernCoffeTable implements CoffeTable {

    @Override
    public void hasLegs() {
        System.out.println("hasLegs:ModernCoffeTable ");
    }

    @Override
    public void sitOn() {

        System.out.println("sitOn:ModernCoffeTable ");

    }
}

