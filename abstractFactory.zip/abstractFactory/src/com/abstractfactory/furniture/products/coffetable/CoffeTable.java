package com.abstractfactory.furniture.products.coffetable;

public interface CoffeTable {

    void hasLegs();

    void sitOn();

}