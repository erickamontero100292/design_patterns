package com.abstractfactory.furniture.products.coffetable;


public class VictorianCoffeTable implements CoffeTable {
    @Override
    public void hasLegs() {
        System.out.println("hasLegs:VictorianCoffeTable ");
    }

    @Override
    public void sitOn() {

        System.out.println("sitOn:VictorianCoffeTable ");

    }
}
