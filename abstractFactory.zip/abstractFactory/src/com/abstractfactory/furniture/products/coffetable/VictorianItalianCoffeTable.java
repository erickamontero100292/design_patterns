package com.abstractfactory.furniture.products.coffetable;


public class VictorianItalianCoffeTable implements CoffeTable {
    @Override
    public void hasLegs() {
        System.out.println("hasLegs:VictorianItalianCoffeTable ");
    }

    @Override
    public void sitOn() {

        System.out.println("sitOn:VictorianItalianCoffeTable ");

    }
}
