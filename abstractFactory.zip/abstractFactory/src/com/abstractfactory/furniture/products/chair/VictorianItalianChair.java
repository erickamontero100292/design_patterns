package com.abstractfactory.furniture.products.chair;


import com.abstractfactory.furniture.products.chair.Chair;

public class VictorianItalianChair implements Chair {
    @Override
    public void hasLegs() {
        System.out.println("hasLegs:VictorianItalianChair ");
    }

    @Override
    public void sitOn() {

        System.out.println("sitOn:VictorianItalianChair ");

    }
}
