package com.abstractfactory.furniture.products.chair;

import com.abstractfactory.furniture.products.chair.Chair;

public class ModernChair implements Chair {

    @Override
    public void hasLegs() {
        System.out.println("hasLegs:ModernChair ");
    }

    @Override
    public void sitOn() {

        System.out.println("sitOn:ModernChair ");

    }
}

