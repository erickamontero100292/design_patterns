package com.abstractfactory.furniture.products.chair;

import com.abstractfactory.furniture.products.chair.Chair;

public class ModernItalianChair implements Chair {

    @Override
    public void hasLegs() {
        System.out.println("hasLegs:ModernItalianChair ");
    }

    @Override
    public void sitOn() {

        System.out.println("sitOn:ModernItalianChair ");

    }
}

