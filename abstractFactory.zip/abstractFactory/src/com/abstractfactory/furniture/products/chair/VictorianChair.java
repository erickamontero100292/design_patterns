package com.abstractfactory.furniture.products.chair;


import com.abstractfactory.furniture.products.chair.Chair;

public class VictorianChair implements Chair {
    @Override
    public void hasLegs() {
        System.out.println("hasLegs:VictorianChair ");
    }

    @Override
    public void sitOn() {

        System.out.println("sitOn:VictorianChair ");

    }
}
