package com.abstractfactory.furniture.products.chair;

public interface Chair {

    void hasLegs();

    void sitOn();

}
