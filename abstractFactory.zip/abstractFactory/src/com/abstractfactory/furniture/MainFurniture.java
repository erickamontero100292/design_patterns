package com.abstractfactory.furniture;

import com.abstractfactory.furniture.products.chair.Chair;
import com.abstractfactory.furniture.products.coffetable.CoffeTable;

public class MainFurniture {

    public static void main(String[] args) {
        System.out.println("-----------------------------------");
        System.out.println("Products Victorian");
        System.out.println("-----------------------------------");
        AbstractFactory factory = ClientFurniture.getFactory("victorian");

        Chair chairVictorian = factory.createChair("victorian");
        Chair chairVictorianItalian = factory.createChair("italian");
        chairVictorian.hasLegs();
        chairVictorianItalian.hasLegs();
        CoffeTable coffeTableVictorian = factory.createCoffeTable("victorian");
        CoffeTable coffeTableItalian = factory.createCoffeTable("italian");
        coffeTableVictorian.hasLegs();
        coffeTableItalian.hasLegs();
        System.out.println("-----------------------------------");
        System.out.println("Products Modern");
        System.out.println("-----------------------------------");
        factory = ClientFurniture.getFactory("modern");

        Chair chairModern = factory.createChair("modern");
        Chair chairModernItalian = factory.createChair("italian");
        chairModern.hasLegs();
        chairModernItalian.hasLegs();

        CoffeTable modernCoffeTable = factory.createCoffeTable("modern");
        CoffeTable italianCoffeTable = factory.createCoffeTable("italian");
        modernCoffeTable.hasLegs();
        italianCoffeTable.hasLegs();


    }
}
