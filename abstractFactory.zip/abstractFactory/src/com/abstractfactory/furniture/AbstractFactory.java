package com.abstractfactory.furniture;

import com.abstractfactory.furniture.products.chair.Chair;
import com.abstractfactory.furniture.products.coffetable.CoffeTable;


public interface AbstractFactory {

    Chair createChair(String model);

    CoffeTable createCoffeTable(String model);
}
