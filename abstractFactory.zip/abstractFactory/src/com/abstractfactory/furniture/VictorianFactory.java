package com.abstractfactory.furniture;


import com.abstractfactory.furniture.products.chair.Chair;
import com.abstractfactory.furniture.products.chair.VictorianChair;
import com.abstractfactory.furniture.products.chair.VictorianItalianChair;
import com.abstractfactory.furniture.products.coffetable.CoffeTable;
import com.abstractfactory.furniture.products.coffetable.VictorianCoffeTable;
import com.abstractfactory.furniture.products.coffetable.VictorianItalianCoffeTable;

public class VictorianFactory implements AbstractFactory {

    @Override
    public Chair createChair(String model) {
        if(model.equalsIgnoreCase("italian")){
            return new VictorianItalianChair();
        }else{
            return new VictorianChair();
        }
    }

    @Override
    public CoffeTable createCoffeTable(String model) {
        if(model.equalsIgnoreCase("italian")){
            return new VictorianItalianCoffeTable();
        }else{
            return new VictorianCoffeTable();
        }
    }
}


