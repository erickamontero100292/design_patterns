package com.abstractfactory.furniture;

import com.abstractfactory.furniture.products.chair.Chair;
import com.abstractfactory.furniture.products.chair.ModernChair;
import com.abstractfactory.furniture.products.chair.ModernItalianChair;
import com.abstractfactory.furniture.products.coffetable.CoffeTable;
import com.abstractfactory.furniture.products.coffetable.ModernCoffeTable;
import com.abstractfactory.furniture.products.coffetable.ModernItalianCoffeTable;

public class ModernFurnitureFactory  implements  AbstractFactory {


    @Override
    public Chair createChair(String model) {
        if(model.equalsIgnoreCase("modern")){
            return new ModernChair();
        }else{
            return new ModernItalianChair();
        }
    }

    @Override
    public CoffeTable createCoffeTable(String model) {
        if(model.equalsIgnoreCase("modern")){
            return new ModernCoffeTable();
        }else{
            return new ModernItalianCoffeTable();
        }
    }
}
