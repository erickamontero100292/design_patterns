package com.builder.factorymethod;

public class Circle  implements Shape {

    @Override
    public void draw() {
        System.out.println("Inside Square::draw() method.");
    }



}
