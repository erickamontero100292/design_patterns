package com.builder.factorymethod;

public interface Shape {

    void draw();
}
